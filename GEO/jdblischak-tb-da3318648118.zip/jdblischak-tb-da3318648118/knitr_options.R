library(knitr)
opts_chunk$set(tidy = FALSE, fig.align = "center")